#include<stdio.h>
#include<string.h>
#include<conio.h>
#define fgRed "\e[31m"
#define fgWhite "\e[37m"
#define fgBlack "\e[30m"
#define fgGreen "\e[32m"
#define fgYellow "\e[33m"
void txtColor(char a[]){
printf("%s",a);
}
void intro(){
    time_t now;
    time(&now);
    printf("\n\n");
    printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n");
    printf("\t\t\t\t\xB2                                                                        \xB2\n");
    printf("\t\t\t\t\xB2 \xDB\xDB\xDB\xDB\xDB\xDB  \xDB    \xDB   \xDB\xDB\xDB\xDB   \xDB     \xDB  \xDB\xDB\xDB\xDB\xDB\xDB  \xDB\xDB\xDB\xDB\xDB    \xDB\xDB\xDB\xDB    \xDB\xDB\xDB\xDB   \xDB   \xDB \xB2\n");
    printf("\t\t\t\t\xB2 \xDB    \xDB  \xDB    \xDB  \xDB    \xDB  \xDB\xDB    \xDB  \xDB       \xDB    \xDB  \xDB    \xDB  \xDB    \xDB  \xDB  \xDB  \xB2\n");
    printf("\t\t\t\t\xB2 \xDB    \xDB  \xDB    \xDB  \xDB    \xDB  \xDB \xDB   \xDB  \xDB       \xDB    \xDB  \xDB    \xDB  \xDB    \xDB  \xDB \xDB   \xB2\n");
    printf("\t\t\t\t\xB2 \xDB\xDB\xDB\xDB\xDB\xDB  \xDB\xDB\xDB\xDB\xDB\xDB  \xDB    \xDB  \xDB  \xDB  \xDB  \xDB\xDB\xDB\xDB\xDB\xDB  \xDB\xDB\xDB\xDB\xDB\xDB  \xDB    \xDB  \xDB    \xDB  \xDB\xDB    \xB2\n");
    printf("\t\t\t\t\xB2 \xDB       \xDB    \xDB  \xDB    \xDB  \xDB   \xDB \xDB  \xDB       \xDB    \xDB  \xDB    \xDB  \xDB    \xDB  \xDB \xDB   \xB2\n");
    printf("\t\t\t\t\xB2 \xDB       \xDB    \xDB  \xDB    \xDB  \xDB    \xDB\xDB  \xDB       \xDB    \xDB  \xDB    \xDB  \xDB    \xDB  \xDB  \xDB  \xB2\n");
    printf("\t\t\t\t\xB2 \xDB       \xDB    \xDB   \xDB\xDB\xDB\xDB   \xDB     \xDB  \xDB\xDB\xDB\xDB\xDB\xDB  \xDB\xDB\xDB\xDB\xDB    \xDB\xDB\xDB\xDB    \xDB\xDB\xDB\xDB   \xDB   \xDB \xB2\n");
    printf("\t\t\t\t\xB2                                                                        \xB2\n");
    printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n");
    printf("\t\t\t\t\t\t\t ===============\n");
    printf("\t\t\t\t\t\t\t   APPLICATION  \n");
    printf("\t\t\t\t\t\t\t ===============");
    printf("\n\n\t\t\t\t\t\t    %s",ctime(&now));
    printf("\n");
}
struct user{
    char name[100];
    char email[50];
    char phone[20];
    char username[50];
    char password[50];
};

void START(){
    system("cls");
    intro();
    int l;
                printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 LOGIN AREA \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");
    printf("\t\t\t\t\t\xDB\xDB\xDB\xDB\xB2 1.SIGNUP\n\n");
    printf("\t\t\t\t\t\xDB\xDB\xDB\xDB\xB2 2.LOGIN\n\n\n");
    printf("\t\t\t\t\t\tENTER CHOICE-> ");
    scanf("%d",&l);
    switch(l){
    case 1:
        reg();
        break;
    case 2:
        login();
        break;
    default:
        printf("\n\n");
        printf("\t\t\t\t\t\tPLEASE ENTER 1 OR 2");Sleep(1500);
        START();
        break;
    }
}
void reg(){
    AGAIN:
    system("cls");
        intro();
         printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 REGISTER AREA \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");
  FILE *fp;
  int i,j;
   char ch,y;
   char us[50];
  struct user user;
fp=fopen("Userlogin.txt","ab+");
 printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 ENTER THE USERNAME ");
scanf("%s",us);
while(fread(&user,sizeof(user),1,fp)==1){
    if(strcmp(us,user.username)==0){
            txtColor(fgRed);
         printf("\n\n\n\t\t\t\t\t\tUSERNAME ALREADY REGISTERED\n");
            txtColor(fgBlack);
         getch();
         reg();
    }
    }
    strcpy(user.username,us);
printf("\n");
printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 ENTER THE PASSWORD ");
while(1){
        ch=getch();
    if(ch==13){
        user.password[i] = '\0';
        break;
    }
    else if(ch==8)
    {
        if(i>0){
        i--;
        printf("\b \b");
        }
    }
    else if(ch==9 || ch==32){
        continue;
    }
    else{
        user.password[i]=ch;
            i++;
            printf("%c",ch);
    }
    }
j=strlen(user.password);
if(j!=0 && j<4){
    printf("\n\n\t\t\t\t\t\tPASSWORD STRENGTH: ");
    txtColor(fgRed);
    printf("WEAK\n\n");
    txtColor(fgBlack);
    printf("\t\t\t\t\tSIGNUP FAILED\n\n");
    printf("\t\t\t\t\tPASSWORD LENGTH CANNOT BE LESS THAN 4\n\n");
    printf("\t\t\t\t\tPLEASE SIGNUP AGAIN");
    getch();
    strcpy(user.password,"");
    reg();
}
else if(j>=4 && j<7){
    printf("\n\n\n\n\t\t\t\t\t\tPASSWORD STRENGTH: ");
    txtColor(fgYellow);
    printf("MEDIUM");
    txtColor(fgBlack);
}
else if(j>6 && j<=9){
   printf("\n\n\n\n\t\t\t\t\t\tPASSWORD STRENGTH: ");
   txtColor(fgGreen);
    printf("STRONG");
    txtColor(fgBlack);
}
else if(j>9 ){
    printf("\n\n\n\n\t\t\t\t\t\tPASSWORD STRENGTH: ");
    txtColor(fgGreen);
    printf("VERY STRONG");
    txtColor(fgBlack);
}
printf("\n\n\n");
fwrite(&user,sizeof(user),1,fp);
fflush(stdin);
if(fwrite!=0){
         txtColor(fgGreen);
    printf("\t\t\t\t\t\t   USERNAME REGISTERED\n");
        txtColor(fgBlack);
}
else{  txtColor(fgRed);
    printf("\t\t\t\t\t\tUSERNAME NOT REGISTERED\n");
    txtColor(fgBlack);
}
fclose(fp);
getch();
START();
}

void login(){
    system("cls");
    intro();
     printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 LOGIN   \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");
    FILE *fp;
    struct user user;
    fp=fopen("Userlogin.txt","rb");
    char usr[50];
    char password[50];
    int i=0,flag=0;
    char ch;
    if(fp==NULL){
            printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 LOGIN \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
            txtColor(fgRed);
            printf("\t\t\t\t\t\tNO CONTACTS SAVED\n");
            Beep(750,100);
            txtColor(fgBlack);
            printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
            START();
        }
        else{
     printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 ENTER THE USERNAME ");
     scanf("%s",usr);
     printf("\n");
     printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 ENTER THE PASSWORD ");
    while(1){
        ch=getch();
    if(ch==13){
        password[i] = '\0';
        break;
    }
    else if(ch==8)
    {
        if(i>0){
        i--;
        printf("\b \b");
        }
    }
    else if(ch==9 || ch==32){
        continue;
    }
    else{
        password[i]=ch;
            i++;
             txtColor(fgRed);
        printf("*");
        txtColor(fgBlack);
    }
    }

    while(fread(&user,sizeof(user),1,fp)){

    if(strcmp(password,user.password)==0)
    {   printf("\n\n\n\n");
        txtColor(fgGreen);
        printf("\t\t\t\t\t\t\tLOGIN SUCCESSFULL\n\n");Beep(1500,300);
        printf("\t\t\t\t\t\tWELCOME TO PHONEBOOK APPLICATION");
        flag=1;
    for(int j=1;j<4;j++){
    printf("->",j);Sleep(1000);
    }
system("cls");
system("color F0");
intro();
    fclose(fp);
    }
    }
    if(flag==0){
        printf("\n");
        txtColor(fgRed);
        printf("\n\n\t\t\t\t\t\t\tINVALID!!!\n");
        Beep(2500,600);
        printf("\n\n\t\t\t\t\t\tUSERNAME OR PASSWORD DOESN'T MATCH\n");
        txtColor(fgBlack);
         printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        system("cls");
        intro();
        START();
        fclose(fp);
    }
        }
}
void takeinput(char ch[50]){
    fgets(ch,50,stdin);
    ch[strlen(ch)-1]=0;

}

void menu(){
    system("cls");
        intro();
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 1.ADD CONTACT\n\n");
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 2.SHOW CONTACT\n\n");
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 3.DELETE CONTACT\n\n");
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 4.SEARCH CONTACT\n\n");
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 5.EDIT CONTACT \n\n");
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 6.EXIT \n\n");
        printf("\n\n\n");

}

void addcontact(){
    FILE *fp;
    char y;
    struct user user;
    system("cls");
        intro();
        AGAIN:
        fgetc(stdin);
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 ADD CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");
        printf("\t\t\t\tENTER NAME\t");
        takeinput(user.name);
        fflush(stdin);
        printf("\t\t\t\tENTER EMAIL\t");
        takeinput(user.email);
        printf("\t\t\t\tENTER NUMBER\t");
        takeinput(user.phone);
        fp=fopen("Users.txt","ab+");
        fwrite(&user,sizeof(user),1,fp);
        if(fwrite!=0){
                printf("\n");
                txtColor(fgGreen);
            printf("\t\t\t\t\t\tCONTACT SAVED\n\n\n");
            Beep(750,300);
            txtColor(fgBlack);
        }
        else{   txtColor(fgRed);
                printf("\t\t\t\t\t\tSOMETHING WENT WRONG\n");
            Beep(750,300);
            txtColor(fgBlack);
        }
        fflush(stdin);
        fclose(fp);
        loop:
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 DO YOU WANT TO ADD ANOTHER CONTACT?(Y/N) ");
        scanf("%c",&y);
        printf("\n\n");
        if(y=='y'||y=='Y'){
                system("cls");
        intro();
            goto AGAIN;
        }
        else if(y=='n'||y=='N'){
                  printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SHOWING ALL CONTACTS \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
                display();
          printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
        Switch();
        }
        else{
                printf("\t\t\t\t\t\tPLEASE ENTER 'Y' OR 'N'\n\n");Sleep(2000);
            getchar();
            system("cls");
        intro();
            goto loop;
        }

}
void display(){
    FILE *fp;
    char y;
    int flag=0;
    struct user user;
    system("cls");
    intro();
 fp=fopen("Users.txt","rb");
        if(fp==NULL){
            printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SHOWING ALL CONTACTS \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
            txtColor(fgRed);
            printf("\t\t\t\t\t\tNO CONTACTS SAVED\n");
            Beep(750,300);
            txtColor(fgBlack);
            printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
        menu();
        Switch();
        }
        else{
               printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SHOWING ALL CONTACTS \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
        while(fread(&user,sizeof(user),1,fp)==1){
                printf("\t\t\t\t===================================================\n");Beep(12000,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S NAME  :   %s\n",user.name);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S EMAIL :   %s\n",user.email);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 MOBILE NUMBER   :   %s\n",user.phone);Sleep(100);Beep(2500,50);
                printf("\n\n");
                flag=1;
              }
              if(flag!=1){
                 txtColor(fgRed);
            printf("\t\t\t\t\t\tNO CONTACTS SAVED\n");
            Beep(750,300);
            txtColor(fgBlack);
          printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
            menu();
            Switch();
              }
        }
        fclose(fp);
       printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
        Switch();
}
void del(){
    FILE *fp;
    int y;
    struct user user;
    system("cls");
    intro();
     printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 DELETE CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
    printf("\t\t\t\t\t\t  ==============================\n");
    printf("\t\t\t\t\t\t\xDB\xDB ENTER 1->DELETE ALL CONTACTS\t\xDB\xDB\n") ;
    printf("\t\t\t\t\t\t\xDB\xDB ENTER 2->DELETE A CONTACT   \t\xDB\xDB\n");
    printf("\t\t\t\t\t\t  ==============================\n\n\n\n");

        printf("\t\t\t\t\tENTER CHOICE-> ");
              scanf("%d",&y);
        printf("\n\n");
      if(y==1){
           remove("./Users.txt");
           txtColor(fgRed);
           printf("\t\t\t\t\t\tAll CONTACT DELETED\n\n"); Beep(2500,1000);
           txtColor(fgBlack);
           printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
            menu();
            Switch();
        }
        else if(y==2){
            printf(" ");
    char phone[50];
    FILE *fp,*temp;
    fp = fopen("Users.txt","rb");
    temp = fopen("temp.txt","wb+");
    if (fp == NULL)
    {    txtColor(fgRed);
        printf("\t\t\t\t\tNO CONTACTS FOUND!!\n");
        txtColor(fgBlack);
       printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
         Switch();
    }
    else
    {
        printf("\t\t\t\t\tENTER CONTACT NUMBER: ");
        getchar();
            scanf("%[^\n]s",&phone);
        int flag = 0;
        while (fread(&user, sizeof(user),1,fp)== 1)
        {
            if(strcmp(phone,user.phone)==0){
            printf("\n\n\t\t\t\t\tSUCCESSFULLY DELETED\n");
            flag=1;
           }
           else{
            fwrite(&user,sizeof(user),1,temp);
           }
           fflush(stdin);
        }
        if(flag ==0)
        {    txtColor(fgRed);
            printf("\n\n\t\t\t\t\tNO RECORD FOUND FOR CONTACT %s \n",phone);
            txtColor(fgBlack);
        }
        fclose(fp);
        fclose(temp);
        remove("Users.txt");
        rename("temp.txt","Users.txt");
        printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
         Switch();
        }
        }
        else {
        printf("\t\t\t\t\tPLEASE ENTER 1 OR 2\n");
        printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        del();
        }
}
void search(){
FILE *fp;
char y;
int flag=0,t;
struct user user;
char ch[50];
AGAIN:
flag=0;
system("cls");
    intro();
    printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SEARCH CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
        fp=fopen("Users.txt","rb");
if(fp==NULL){
         txtColor(fgRed);
    printf("\t\t\t\t\t\tNO CONTACTS FOUND\n");
txtColor(fgBlack);
        printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
         Switch();
}
else{
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 1.SEARCH BY NUMBER\n\n");
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xB2 2.SEARCH BY NAME\n\n\n");
        printf("\t\t\t\t\t\tENTER CHOICE-> ");
        scanf("%d",&t);
        printf("\n\n");
    switch(t){
     case 1:
        printf("\t\t\t\tENTER THE CONTACT NUMBER ");
getchar();
scanf("%[^\n]s",&ch);
printf("\n\n");
while(fread(&user,sizeof(user),1,fp)){
    if(strcmp(ch,user.phone)==0){
             txtColor(fgGreen);
            printf("\t\t\t\t\t\tCONTACT FOUND\n\n");Sleep(600);
            txtColor(fgBlack);
            system("cls");
            intro();
            printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SEARCH CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
       printf("\t\t\t\t===================================================\n");Beep(13000,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S NAME  :   %s\n",user.name);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S EMAIL :   %s\n",user.email);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 MOBILE NUMBER   :   %s\n",user.phone);Sleep(100);Beep(2500,50);
                printf("\n\n");
                flag=1;
    }
}
    if(flag==0){
        printf("\t\t\t\t\tNO RECORD FOUND FOR CONTACT %s \n\n\n",ch);
    }
fclose(fp);
loop:
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 DO YOU WANT TO SEARCH ANOTHER CONTACT?(Y/N) ");
        getchar();
        scanf("%c",&y);
        printf("\n\n");
        if(y=='y'||y=='Y'){
            goto AGAIN;
        }
        else if(y=='n'||y=='N'){
        menu();
        Switch();
        }
        else{
                printf("\t\t\t\t\t\tPLEASE ENTER 'Y' OR 'N'\n\n\n");
                printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
            goto loop;
  }
  case 2:
        printf("\t\t\t\tENTER THE CONTACT NAME ");
getchar();
scanf("%[^\n]s",&ch);
printf("\n\n");
while(fread(&user,sizeof(user),1,fp)){
    if(strcmp(ch,user.name)==0){
             txtColor(fgGreen);
            printf("\t\t\t\t\t\tCONTACT FOUND\n\n");Sleep(600);
            txtColor(fgBlack);
            system("cls");
            intro();
            printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SEARCH CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
       printf("\t\t\t\t===================================================\n");Beep(13000,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S NAME  :   %s\n",user.name);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S EMAIL :   %s\n",user.email);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 MOBILE NUMBER   :   %s\n",user.phone);Sleep(100);Beep(2500,50);
                printf("\n\n");
                flag=1;
    }
}
    if(flag==0){
        printf("\t\t\t\t\tNO RECORD FOUND FOR CONTACT %s \n\n\n",ch);
    }
fclose(fp);
loop2:
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 DO YOU WANT TO SEARCH ANOTHER CONTACT?(Y/N) ");
        getchar();
        scanf("%c",&y);
        printf("\n\n");
        if(y=='y'||y=='Y'){
            goto AGAIN;
        }
        else if(y=='n'||y=='N'){
        menu();
        Switch();
        }
        else{
                printf("\t\t\t\t\t\tPLEASE ENTER 'Y' OR 'N'\n\n\n");
                printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
            goto loop2;
  }
  default:
    printf("\t\t\t\tPLEASE ENTER 1 OR 2");
    getch();
        search();

}
}
}
     void edit(){
FILE *fp,*temp;
int flag=0;
char y;
struct user user;
char ch[50];
 AGAIN:
     flag=0;
system("cls");
    intro();
    printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 EDIT CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
fp=fopen("Users.txt","rb");
temp = fopen("temp.txt","wb+");
if(fp==NULL){
     txtColor(fgRed);
    printf("\t\t\t\t\t\tNO CONTACTS FOUND\n");
txtColor(fgBlack);
        printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
        Switch();
}
else{
printf("\t\t\t\tENTER THE CONTACT NUMBER ");
getchar();
scanf("%[^\n]s",&ch);
printf("\n\n\n");
while(fread(&user,sizeof(user),1,fp)==1){
    if(strcmp(ch,user.phone)==0){
            getchar();
        printf("\t\t\t\tENTER NAME\t");
        takeinput(user.name);
        fflush(stdin);
        printf("\t\t\t\tENTER EMAIL\t");
        takeinput(user.email);
        printf("\t\t\t\tENTER NUMBER\t");
        takeinput(user.phone);
        flag=1;
            fwrite(&user,sizeof(user),1,temp);
             if(fwrite!=0){
                printf("\n");
                txtColor(fgGreen);
            printf("\t\t\t\t\t\tCONTACT UPDATED\n\n\n");
            Beep(750,300);
            txtColor(fgBlack);
                 printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 SHOWING EDITED CONTACT \xB2\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\n\n\n");Sleep(600);
             printf("\t\t\t\t===================================================\n");Beep(13000,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S NAME  :   %s\n",user.name);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 CONTACT'S EMAIL :   %s\n",user.email);Sleep(100);Beep(2500,50);
                printf("\t\t\t\t\xDB\xB2 MOBILE NUMBER   :   %s\n",user.phone);Sleep(100);Beep(2500,50);
                printf("\n\n\n");
        }
        else{
            txtColor(fgRed);
            printf("\t\t\t\t\t\t CONTACTS CAN'T UPDATED\n");
            Beep(750,300);
            txtColor(fgBlack);
             printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
        menu();
        Switch();
        }
    }
    else{
            fwrite(&user,sizeof(user),1,temp);
        fflush(stdin);
    }
}
        if(flag==0){
            printf("\t\t\t\t\tNO RECORD FOUND FOR CONTACT %s \n\n\n",ch);
        }
        fflush(stdin);
        fclose(fp);
        fclose(temp);
        remove("Users.txt");
        rename("temp.txt","Users.txt");
        loop:
        printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 DO YOU WANT TO EDIT ANOTHER CONTACT?(Y/N) ");
        scanf("%c",&y);
        printf("\n\n");
        if(y=='y'||y=='Y'){
            goto AGAIN;
        }
        else if(y=='n'||y=='N'){
        menu();
        Switch();
        }
        else{
                printf("\t\t\t\t\t\tPLEASE ENTER 'Y' OR 'N'\n\n\n");
              printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
            getch();
            goto loop;
        }
}
}
void Switch(){
    int t;
    printf("\t\t\t\t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 WHICH ONE YOU WANT TO CHOOSE ");
    scanf("%d",&t);
    printf("\n\n\n");
    switch(t){
    case 1:
       addcontact();
    break;
    case 2:
       display();
        break;
  case 3:
      del();
        break;
  case 4:
        search();
        break;
  case 5:
      edit();
      break;
  case 6:
      system("cls");
      intro();
      printf("\t\t\t\t-> THANK YOU FOR USING THE APPLICATION\n\n");Sleep(800);
      printf("\t\t\t\t-> BE ALWAYS HAPPY AND STAY WELL\n\n");Sleep(800);
      printf("\t\t\t\t-> MAY ALLAH BLESS YOU\n");Sleep(800);
      printf("\n\n\n");
      printf("\t\t\t\t\xDB\xDB\xB2 DEVELOPED BY:\n\n");Sleep(800);
      printf("\t\t\t\t\tFAISAL AHMED\n");Sleep(800);
      printf("\t\t\t\t\tSHEMA AKTER\n");Sleep(800);
      printf("\t\t\t\t\tJANNATUL FERDOUS MITU\n");Sleep(800);
        Beep(2500,1000);
        exit(0);
  default:
      txtColor(fgRed);
        printf("\t\t\t\t\t\tPLEASE CHOOSE BETWEEN 1 TO 6\n");
        Beep(2500,700);
        txtColor(fgBlack);
        printf("\n\n\n\t\t\t\t\t====== PRESS ANY KEY TO CONTINUE======");
        getch();
        menu();
         Switch();
         break;
}
}
int main(){
    system("color F0");
     intro();
     START();
    menu();
    Switch();
    return 0;
}
